import React, { Component } from 'react'

class ComponentName extends Component {
    render () {
        return (
            <div>
                        <div>
                                加载页面
                        </div>
            </div>
        )
    }
}

export default ComponentName