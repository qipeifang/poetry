// 古籍组件

import React, { Component } from 'react'
import Head from '../header/index'

class Poet extends Component {
  render () {
    return (
      <div>
        <Head />
        古籍组件
      </div>
    )
  }
}

export default Poet