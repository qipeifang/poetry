// 名句组件

import React, { Component } from 'react'
import Head from '../header/index'

class Rhesis extends Component {
  render () {
    return (
      <div>
        <Head />
        名句
      </div>
    )
  }
}

export default Rhesis